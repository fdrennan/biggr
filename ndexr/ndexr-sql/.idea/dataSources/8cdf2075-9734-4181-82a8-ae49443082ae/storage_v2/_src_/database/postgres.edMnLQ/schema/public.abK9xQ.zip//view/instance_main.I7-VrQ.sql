create view instance_main
            (user_id, id, status, time, creation_time, key_name, instance_type, image_id, security_group_id,
             instance_storage, keyfile)
as
WITH instance_status AS (
    SELECT x.id,
           x.status,
           x."time",
           x.row_id
    FROM (SELECT instance_status.id,
                 instance_status.status,
                 instance_status."time",
                 row_number() OVER (PARTITION BY instance_status.id ORDER BY instance_status."time" DESC) AS row_id
          FROM public.instance_status
          ORDER BY instance_status.id) x
    WHERE x.row_id = 1
),
     keyfiles AS (
         SELECT kf.created_at,
                kf.key_file_name,
                kf.keyfile,
                kf.row_id
         FROM (SELECT keyfiles.created_at,
                      keyfiles.key_file_name,
                      keyfiles.keyfile,
                      row_number()
                      OVER (PARTITION BY keyfiles.key_file_name ORDER BY keyfiles.created_at DESC) AS row_id
               FROM public.keyfiles) kf
         WHERE kf.row_id = 1
     ),
     created_at AS (
         SELECT instance_created.user_id,
                instance_created.creation_time,
                instance_created.id,
                instance_created.key_name,
                instance_created.instance_type,
                instance_created.image_id,
                instance_created.security_group_id,
                instance_created.instance_storage
         FROM instance_created
     ),
     joined AS (
         SELECT ca.user_id,
                ca.id,
                ins.status,
                ins."time",
                ca.creation_time,
                ca.key_name,
                ca.instance_type,
                ca.image_id,
                ca.security_group_id,
                ca.instance_storage,
                kf.keyfile
         FROM instance_status ins
                  LEFT JOIN created_at ca ON ins.id = ca.id
                  LEFT JOIN keyfiles kf ON kf.key_file_name = ca.key_name
     )
SELECT joined.user_id,
       joined.id,
       joined.status,
       joined."time",
       joined.creation_time,
       joined.key_name,
       joined.instance_type,
       joined.image_id,
       joined.security_group_id,
       joined.instance_storage,
       joined.keyfile
FROM joined;

alter table instance_main
    owner to fdrennan;

